import open3d as o3d
import numpy as np
import cv2
import os



class CanonicalCamera_pointcloud: 
    def __init__(self, resolution=768, bounds=0.55, thickness=0.2576):  #thickness=0.2576
        self.W = resolution
        self.H = resolution
        self.bounds = bounds
        self.thickness = thickness
        u, v = np.meshgrid(np.arange(self.W), np.arange(self.H))
        self.grid_X = np.interp(u, (0, self.W), (-self.bounds, self.bounds))
        self.grid_Y = np.interp(v, (0, self.H), (self.bounds, -self.bounds))

    def project_depth_to_points(self, depth_map, mask=None):
        if mask is None: mask = ~np.isnan(depth_map)
        d_min, d_max = np.nanmin(depth_map), np.nanmax(depth_map)
        depth_norm = (depth_map - d_min) / (d_max - d_min) if (d_max - d_min) > 1e-6 else np.zeros_like(depth_map)
        grid_Z = (depth_norm * self.thickness) - (self.thickness / 2.0)
        points = np.stack([self.grid_X, self.grid_Y, grid_Z], axis=2)
        return points[mask]

class MultiViewRenderer:
    def __init__(self, camera_config: CanonicalCamera_pointcloud, output_root="render_3d_previews"):
        self.camera = camera_config
        self.output_root = output_root
        
        # --- Class Defaults ---
        self.default_az = [0, 45, 90, 0, 0]
        self.default_el = [0, 0, 0, 45, 89.9]
        self.default_dist = 1.8

    def _get_front_vector(self, azim_deg, elev_deg):
        azim, elev = np.radians(azim_deg), np.radians(elev_deg)
        return [np.cos(elev) * np.sin(azim), np.sin(elev), np.cos(elev) * np.cos(azim)]

    def render_from_npy(self, npy_data, rgb_path, save_path_name, mask_path=None):
        """
        Takes depth (path or array), RGB path, and subfolder name for saving.
        """
        # 1. Create directory
        current_save_dir = os.path.join(self.output_root, save_path_name)
        os.makedirs(current_save_dir, exist_ok=True)

        # 2. Load Depth
        if isinstance(npy_data, str):
            depth_map = np.load(npy_data)
        else:
            depth_map = npy_data
        
        # 3. Load and align RGB
        rgb = cv2.imread(rgb_path)
        if rgb is None: 
            raise FileNotFoundError(f"Missing RGB image at: {rgb_path}")
        
        #load mask
        if mask_path is not None:
            mask_img = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
            mask = mask_img > 127  # Convert to boolean mask
        else:
            mask = ~np.isnan(depth_map)
            print("⚠️ No mask provided, using depth validity as mask.")
        
        # FIXED LINE HERE:
        rgb = cv2.cvtColor(rgb, cv2.COLOR_BGR2RGB)
        
        if rgb.shape[:2] != depth_map.shape:
            rgb = cv2.resize(rgb, (self.camera.W, self.camera.H), interpolation=cv2.INTER_AREA)

        
            
            
        
        points = self.camera.project_depth_to_points(depth_map, mask=mask)
        colors = rgb[mask] / 255.0
        
        
      

        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(points)
        pcd.colors = o3d.utility.Vector3dVector(colors)
        
        # --- NEW: SAVE AS PLY ---
        ply_save_path = os.path.join(current_save_dir, f"{save_path_name}.ply")
        # write_point_cloud automatically handles the headers for XYZ and RGB
        o3d.io.write_point_cloud(ply_save_path, pcd)
        print(f"📦 Saved PointCloud PLY to: {ply_save_path}")
        # ------------------------

        # 5. Execute Rendering
        self._execute_rendering(pcd, current_save_dir)



    def _execute_rendering(self, pcd, save_dir):
        vis = o3d.visualization.Visualizer()
        vis.create_window(width=self.camera.W, height=self.camera.H, visible=False)
        vis.add_geometry(pcd)
        
        opt = vis.get_render_option()
        opt.background_color = np.asarray([1, 1, 1])
        opt.point_size = 2.0 
        
        ctr = vis.get_view_control()

        for az, el in zip(self.default_az, self.default_el):
            front = np.array(self._get_front_vector(az, el))
            
            # Setup pseudo-orthographic view
            ctr.set_front(front)
            ctr.set_lookat([0, 0, 0])
            ctr.set_up([0, 1, 0])
            
            # Use small FOV to simulate Orthographic
            ctr.change_field_of_view(step=-90) 
            ctr.set_zoom(0.55) 

            vis.poll_events()
            vis.update_renderer()
            
            file_name = f"ortho_az{az}_el{el}.png"
            vis.capture_screen_image(os.path.join(save_dir, file_name))
            
        print(f"✅ Renders successfully saved to: {save_dir}")
        vis.destroy_window()

# --- Execution ---
if __name__ == "__main__":
    cam = CanonicalCamera_pointcloud()
    renderer = MultiViewRenderer(cam)
    
    # Update these paths to your actual files
    NPY_PATH = "intermediate_input/depth_npy/input_768_gray_bg_depth.npy"
    RGB_PATH = "intermediate_input/input_768_gray_bg.jpg"
    SAVE_NAME = "raw_depth_views"

    renderer.render_from_npy(NPY_PATH, RGB_PATH, SAVE_NAME)