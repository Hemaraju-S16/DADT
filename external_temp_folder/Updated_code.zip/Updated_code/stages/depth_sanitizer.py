from .baseline_projector import PipelineStage
import numpy as np
import open3d as o3d
import cv2
import scipy.sparse as sp
from scipy.sparse.linalg import spsolve
import os


class NormalSanitizer(PipelineStage):
    """
    Stage 1.5: Cleans Surface Normals before they guide depth.
    Renormalizes vectors and removes high-frequency 'sparkle' noise.
    """
    def run(self, normal_path, mask_path):
        self.log("Sanitizing Surface Normals...")
        
        # 1. Load
        normals = np.load(normal_path).astype(np.float32)
        if normals.ndim == 3 and normals.shape[0] == 3: normals = normals.transpose(1, 2, 0)
        
        mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE) > 127
        H, W = normals.shape[:2]
        
        # 2. Renormalize (Crucial)
        # Often raw normals are not perfectly unit length
        norm_mag = np.linalg.norm(normals, axis=2, keepdims=True)
        # Avoid div by zero
        normals_clean = normals / (norm_mag + 1e-6)
        
        # 3. Mild Smoothing (Bilateral) on Normals
        # We want to remove single-pixel noise from the normals themselves
        # without destroying the sharp edges (creases) they represent.
        
        # We filter each channel (X, Y, Z) but use the Normal map itself as the guide.
        # This effectively smoothes the vector field direction.
        
        # Pad first
        kernel = np.ones((3,3), np.uint8)
        normals_padded = cv2.dilate(normals_clean, kernel, iterations=1)
        
        # Filter
        # SigmaColor small (0.1) -> Don't blur if direction changes > 10%
        # SigmaSpace small (5) -> Local smoothing only
        normals_smooth = cv2.bilateralFilter(normals_padded, d=5, sigmaColor=0.1, sigmaSpace=5)
        
        # Re-apply mask & Re-normalize (Filtering can shorten vectors)
        final_normals = np.zeros_like(normals)
        final_normals[mask] = normals_smooth[mask]
        
        norm_mag2 = np.linalg.norm(final_normals, axis=2, keepdims=True)
        final_normals = final_normals / (norm_mag2 + 1e-6)
        
        # 4. Save
        out_path = os.path.join(self.output_dir, "stage1_cleaned_normals.npy")
        np.save(out_path, final_normals)
        self.log(f"Saved Cleaned Normals to {out_path}")
        
        # 5. Debug Comparison
        # Visualize the difference in the Blue channel (Z-component)
        self.save_comparison_report(normals[..., 2], final_normals[..., 2], mask, "Normal Sanitization (Z-Channel)")
        
        return out_path



class DepthSanitizer(PipelineStage):
    """
    Stage 2 (Refined): Smoothes the valid surface using Normal guidance.
    CRITICAL FIX: Does NOT infill holes. Preserves NaNs for Stage 3.
    """
    def run(self, depth_npy, normal_npy, mask_path):
        self.log(f"Sanitizing valid depth pixels (Preserving NaNs)...")
        
        # 1. Load Data
        depth = np.load(depth_npy).astype(np.float32) # Contains NaNs
        if depth.ndim == 3: depth = depth.squeeze()
        
        normals = np.load(normal_npy).astype(np.float32)
        if normals.ndim == 3 and normals.shape[0] == 3: 
            normals = normals.transpose(1, 2, 0)
            
        mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE) > 127
        
        # 2. Identify "Holes" (NaNs inside the mask)
        # We must track these to ensure we don't accidentally fill them with blur
        valid_pixels_mask = mask & (~np.isnan(depth))
        
        # 3. Pre-process for Filtering (Handle NaNs temporarily)
        # We fill NaNs with 0 just so the filter math works, 
        # BUT we will discard these pixels later.
        depth_safe = depth.copy()
        depth_safe[np.isnan(depth_safe)] = 0
        
        # Pad/Dilate to handle boundary conditions
        kernel = np.ones((5,5), np.uint8)
        depth_padded = cv2.dilate(depth_safe, kernel, iterations=3)
        normals_padded = cv2.dilate(normals, kernel, iterations=3)
        
        # 4. Joint Bilateral Filter (The Smoothing)
        # This removes the "stair-stepping" noise from Marigold
        try:
            from cv2.ximgproc import jointBilateralFilter
            # Reduced d=5 for less aggressive smoothing
            sanitized = jointBilateralFilter(
                joint=normals_padded, 
                src=depth_padded, 
                d=5,             # Smaller neighborhood (was 10)
                sigmaColor=0.10, # Reduced influence
                sigmaSpace=5
            )
        except ImportError:
            sanitized = cv2.bilateralFilter(depth_padded, d=5, sigmaColor=0.05, sigmaSpace=5)
            
        # 5. RESTORE HOLES (Critical Step)
        # We create the output canvas
        final_depth = np.full_like(depth, np.nan)
        
        # We ONLY write back to pixels that were VALID to begin with.
        # This keeps the NaNs (holes) empty for Stage 3.
        final_depth[valid_pixels_mask] = sanitized[valid_pixels_mask]
        
        # 6. Save Outputs
        output_npy = os.path.join(self.output_dir, "stage2_sanitized.npy")
        np.save(output_npy, final_depth)
        self.log(f"Saved sanitized depth to {output_npy}")
        
        # 7. Comparison Report
        # Compare only valid pixels to valid pixels
        depth_viz = depth.copy(); depth_viz[np.isnan(depth_viz)] = 0
        final_viz = final_depth.copy(); final_viz[np.isnan(final_viz)] = 0
        
        self.save_comparison_report(depth_viz, final_viz, valid_pixels_mask, "Stage 2 Sanitization (No Infill)")
        
        return output_npy