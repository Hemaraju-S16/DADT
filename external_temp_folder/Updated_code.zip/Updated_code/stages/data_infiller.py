import numpy as np
import cv2
import os
import matplotlib.pyplot as plt
from .baseline_projector import PipelineStage, CanonicalCamera

class DataInfiller(PipelineStage):
    """
    Stage 3: Surgically fills ONLY the NaN holes.
    Valid pixels remain untouched.
    """
    def run(self, stage1_depth_path, stage1_normal_path, mask_path):
        self.log("Running Hole Infilling (Valid pixels will be preserved)...")
        
        # 1. Load Data (Stage 1 Output has NaNs)
        depth = np.load(stage1_depth_path)
        normals = np.load(stage1_normal_path)
        mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE) > 127
        
        # 2. Identify Holes
        # A hole is a pixel inside the mask that is NaN (from Stage 1 removal)
        # OR exactly zero (missing data)
        is_hole = (np.isnan(depth) | (np.abs(depth) < 1e-6)) & mask
        
        num_holes = np.sum(is_hole)
        self.log(f"Found {num_holes} pixels to infill.")
        
        if num_holes == 0:
            self.log("No holes found. Saving copy.")
            self.save_outputs(depth, normals)
            return
            
        # Create a mask for CV2 Inpainting (uint8)
        hole_mask_uint8 = is_hole.astype(np.uint8) * 255
        # Dilate slightly to ensure we grab valid boundary pixels for blending
        hole_mask_uint8 = cv2.dilate(hole_mask_uint8, np.ones((3,3), np.uint8))

        # 3. Infill Depth
        # We perform inpainting on a Normalized copy, then map back.
        d_min, d_max = np.nanmin(depth), np.nanmax(depth)
        
        # Normalize to 0-1 (Handle NaNs by setting to 0 temp)
        depth_norm = (depth - d_min) / (d_max - d_min)
        depth_norm[np.isnan(depth_norm)] = 0 
        
        # Map to 16-bit for precision (0..65535)
        depth_u16 = (depth_norm * 65535).astype(np.uint16)
        
        # Inpaint (Navier-Stokes)
        depth_filled_u16 = cv2.inpaint(depth_u16, hole_mask_uint8, 3, cv2.INPAINT_NS)
        
        # Map back to Float
        depth_filled_float = (depth_filled_u16.astype(np.float32) / 65535.0) * (d_max - d_min) + d_min
        
        # CRITICAL: Copy ONLY the filled holes back to the original array.
        # This ensures valid pixels are not touched by the inpainting blur.
        final_depth = depth.copy()
        final_depth[is_hole] = depth_filled_float[is_hole]

        # 4. Infill Normals (Channel by Channel)
        # Holes in depth usually mean holes in Normals too.
        final_normals = normals.copy()
        for c in range(3):
            n_chan = normals[..., c]
            
            # Map -1..1 -> 0..255
            n_vis = ((n_chan + 1) / 2.0 * 255).astype(np.uint8)
            
            # Inpaint
            n_inp = cv2.inpaint(n_vis, hole_mask_uint8, 3, cv2.INPAINT_NS)
            
            # Map back -> -1..1
            n_fixed = (n_inp.astype(np.float32) / 255.0) * 2.0 - 1.0
            
            # Apply ONLY to holes
            final_normals[..., c] = np.where(is_hole, n_fixed, final_normals[..., c])
            
        # Renormalize (Unit Length) only in hole regions to save time? 
        # Safer to renormalize everywhere or just holes. Let's do all to be safe.
        norm_mag = np.linalg.norm(final_normals, axis=2, keepdims=True)
        final_normals = final_normals / (norm_mag + 1e-6)

        # 5. Save & Verify
        d_out, n_out = self.save_outputs(final_depth, final_normals)
        
        # 6. Verify "Surgical" Accuracy
        # Check if valid pixels changed (Should be 0.0 change)
        valid_mask = mask & (~is_hole)
        diff = np.abs(final_depth[valid_mask] - depth[valid_mask])
        max_change = np.nanmax(diff)
        self.log(f"Verification: Max change to valid pixels = {max_change:.6f} (Should be 0.0)")
        
        # 7. Debug Map (Show where we filled)
        self.save_hole_debug(depth, final_depth, is_hole)
        
        return d_out, n_out

    def save_outputs(self, d, n):
        d_out = os.path.join(self.output_dir, "stage3_filled_depth.npy")
        n_out = os.path.join(self.output_dir, "stage3_filled_normals.npy")
        np.save(d_out, d)
        np.save(n_out, n)
        self.log(f"Saved Infilled Depth: {d_out}")
        return d_out, n_out

    def save_hole_debug(self, before, after, is_hole):
        # Visualize where holes were
        plt.figure(figsize=(12, 6))
        
        plt.subplot(1, 2, 1)
        plt.title("Holes (Red)")
        # Normalize for viz
        viz = (before - np.nanmin(before)) / (np.nanmax(before) - np.nanmin(before))
        # Create RGB
        cmap = plt.cm.Spectral_r
        viz_rgb = cmap(viz)
        # Paint holes Red
        viz_rgb[is_hole] = [1, 0, 0, 1]
        plt.imshow(viz_rgb)
        plt.axis('off')
        
        plt.subplot(1, 2, 2)
        plt.title("After Infilling")
        plt.imshow(after, cmap='Spectral_r')
        plt.axis('off')
        
        path = os.path.join(self.output_dir, "stage3_debug.jpg")
        plt.savefig(path)
        plt.close()
        self.log(f"Saved debug view: {path}")

