import numpy as np
import open3d as o3d
import cv2
import scipy.sparse as sp
from scipy.sparse.linalg import spsolve
import os
import matplotlib.pyplot as plt


# --- 1. THE CAMERA DEFINITION ---
class CanonicalCamera:
    """
    Single source of truth for the imaging setup.
    Prevents hardcoding '0.55' or '768' in multiple places.
    """
    def __init__(self, resolution=768, bounds=0.55, thickness=0.8): #thickness=0.2576
        self.W = resolution
        self.H = resolution
        self.bounds = bounds        # +/- 0.55 units
        self.thickness = thickness  # Z-depth thickness (approx)
        
        
        # Pre-compute the projection grids (Vectorized)
        # This saves time in every stage
        u, v = np.meshgrid(np.arange(self.W), np.arange(self.H))
        
        # Linear Mapping: Pixel (0..W) -> World (-Bound..+Bound)
        self.grid_X = np.interp(u, (0, self.W), (-self.bounds, self.bounds))
        self.grid_Y = np.interp(v, (0, self.H), (self.bounds, -self.bounds)) # Y-Up convention



    def project_depth_to_points(self, depth_map, mask=None):
        """
        Converts a depth map to a (N,3) point cloud array using this camera.
        """
        # Normalize depth 0..1 -> Physical Z
        d_min, d_max = depth_map.min(), depth_map.max()
        if d_max - d_min < 1e-6:
            depth_norm = depth_map # Flat
        else:
            depth_norm = (depth_map - d_min) / (d_max - d_min)
            
        # Map 0..1 to physical thickness centered at 0
        grid_Z = (depth_norm * self.thickness) - (self.thickness / 2.0)
        
        # Stack
        points = np.stack([self.grid_X, self.grid_Y, grid_Z], axis=2)
        
        if mask is not None:
            return points[mask] # Returns (N, 3)
        return points # Returns (H, W, 3)


# --- 2. THE PIPELINE STAGE BASE ---
class PipelineStage:
    """
    Base class containing logging, I/O, and Error Analysis tools.
    """
    def __init__(self, output_dir, camera: CanonicalCamera):
        self.output_dir = output_dir
        self.cam = camera # Access camera config anywhere via self.cam
        os.makedirs(self.output_dir, exist_ok=True)
    
    def log(self, msg):
        print(f"[{self.__class__.__name__}] {msg}")

    def save_comparison_report(self, before_map, after_map, mask, stage_name):
        """
        Generates a visual report comparing input vs output.
        Saves a heatmap showing EXACTLY what changed.
        """
        # 1. Calculate Difference (Delta)
        # We focus only on the valid masked region
        valid_mask = mask > 0
        
        diff = np.abs(after_map - before_map)
        diff[~valid_mask] = 0 # Ignore background noise
        
        # Stats
        mae = np.mean(diff[valid_mask]) # Mean Absolute Error
        max_diff = np.max(diff[valid_mask])
        
        self.log(f"Change Report: Mean Delta={mae:.5f}, Max Delta={max_diff:.5f}")

        # 2. Plotting
        fig, axes = plt.subplots(1, 3, figsize=(18, 6))
        fig.suptitle(f"{stage_name} Comparison (MAE: {mae:.4f})", fontsize=16)
        
        # Input
        ax = axes[0]
        im = ax.imshow(before_map, cmap='Spectral_r')
        ax.set_title("Before")
        plt.colorbar(im, ax=ax, fraction=0.046)
        
        # Output
        ax = axes[1]
        im = ax.imshow(after_map, cmap='Spectral_r')
        ax.set_title("After")
        plt.colorbar(im, ax=ax, fraction=0.046)
        
        # Difference Heatmap (The most important part)
        ax = axes[2]
        # Use a high-contrast colormap (black=no change, bright=big change)
        im = ax.imshow(diff, cmap='magma', vmin=0, vmax=np.percentile(diff[valid_mask], 99))
        ax.set_title("Difference Heatmap (What Changed)")
        plt.colorbar(im, ax=ax, fraction=0.046)
        
        # Save
        filename = f"{stage_name.lower().replace(' ', '_')}_comparison.jpg"
        path = os.path.join(self.output_dir, filename)
        plt.tight_layout()
        plt.savefig(path, dpi=100)
        plt.close()
        
        self.log(f"Saved Comparison Report: {path}")




class BaselineProjector(PipelineStage):
    """
    Stage 1: Generates the baseline 3D point cloud from raw data.
    CRITICAL UPDATE: Removes statistical outliers and saves a "Cleaned Depth Map"
    (with NaNs) for downstream stages.
    """
    def run(self, rgb_path, depth_path, mask_path):
        self.log(f"Processing {os.path.basename(rgb_path)}...")
        
        # A. Load Data
        rgb = cv2.imread(rgb_path)
        if rgb is None: raise ValueError(f"RGB not found: {rgb_path}")
        rgb = cv2.cvtColor(rgb, cv2.COLOR_BGR2RGB)
        
        depth = np.load(depth_path).astype(np.float32)
        if depth.ndim == 3: depth = depth.squeeze()
        
        mask = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE) > 127
        
        # B. Project to 3D (Using Camera Class)
        self.log("Projecting depth to Canonical 3D space...")
        # Note: self.cam must be available from PipelineStage.__init__
        points = self.cam.project_depth_to_points(depth, mask=mask)
        
        # Get colors for valid points
        colors = rgb[mask] / 255.0
        
        # C. Create Open3D Cloud
        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(points)
        pcd.colors = o3d.utility.Vector3dVector(colors)
        
        # D. Statistical Outlier Removal (SOR)
        raw_count = len(points)
        self.log(f"Running SOR on {raw_count} points...")
        
        # std_ratio=2.0 is conservative.
        # ind_list contains indices of the points that *SURVIVED*
        pcd_clean, ind_list = pcd.remove_statistical_outlier(nb_neighbors=20, std_ratio=2.0)
        clean_count = len(pcd_clean.points)
        removed_count = raw_count - clean_count
        
        self.log(f"SOR Complete: Removed {removed_count} points ({removed_count/raw_count:.1%})")

        # --- NEW LOGIC: Map Survivors back to 2D Depth --- 
        
        # 1. Get global indices of valid pixels (relative to flattened image)
        flat_indices = np.where(mask.flatten())[0]
        
        # 2. Get global indices of survivors
        # ind_list matches indices in 'points', which match 'flat_indices'
        survivor_indices = flat_indices[ind_list]
        
        # 3. Create a Survivor Mask (2D)
        survivor_mask = np.zeros(depth.shape, dtype=bool)
        survivor_rows, survivor_cols = np.unravel_index(survivor_indices, depth.shape)
        survivor_mask[survivor_rows, survivor_cols] = True
        
        # 4. Create Cleaned Depth Map
        # Start with original depth
        cleaned_depth = depth.copy()
        
        # Set anything NOT in survivor mask to NaN
        # This removes:
        #   1. Original background (already false in mask)
        #   2. The "Flying Pixels" removed by SOR
        cleaned_depth[~survivor_mask] = np.nan
        
        # E. Save Outputs
        
        # 1. Save Cleaned Depth (NPY) -> CRITICAL for Stage 2
        clean_depth_path = os.path.join(self.output_dir, "stage1_cleaned_depth.npy")
        #show min and max before saving
        print(f"cleaned depth min is {np.nanmin(cleaned_depth)}, max is {np.nanmax(cleaned_depth)}")
        
        
        np.save(clean_depth_path, cleaned_depth)
        self.log(f"Saved Cleaned Depth Map to {clean_depth_path}")
        
        # 2. Save Cleaned Point Cloud (PLY) -> For visualization
        out_ply = os.path.join(self.output_dir, "stage1_baseline.ply")
        o3d.io.write_point_cloud(out_ply, pcd_clean)
        self.log(f"Saved Cleaned Point Cloud to {out_ply}")
        
        # F. Debug Visualization (The Kill Map)
        self.save_debug_image(rgb, depth, mask, ind_list)
        
        # Return path to the CLEANED depth, not the ply. 
        # The pipeline needs the .npy file for the next step.
        return clean_depth_path
    
    
    

    def save_debug_image(self, rgb, depth, mask, keep_indices):
        """Visualizes which pixels were deleted by SOR."""
        H, W = depth.shape
        
        # Create a blank map
        kill_map = np.zeros((H, W, 3), dtype=np.uint8)
        
        # 1. Fill Valid Mask area with GRAY (Context)
        kill_map[mask] = [100, 100, 100]
        
        # 2. Identify Deleted Points for Visualization
        flat_mask_indices = np.where(mask.flatten())[0]
        survivor_global_indices = flat_mask_indices[keep_indices]
        
        survivor_map = np.zeros((H*W), dtype=bool)
        survivor_map[survivor_global_indices] = True
        survivor_map_2d = survivor_map.reshape(H, W)
        
        # 3. Mark Deleted points as RED
        # Logic: Inside original Mask BUT NOT in Survivor Map
        killed_mask = mask & (~survivor_map_2d)
        kill_map[killed_mask] = [255, 0, 0] # RED
        
        # Plot
        plt.figure(figsize=(12, 5))
        plt.subplot(1, 2, 1)
        plt.title("Marigold Depth")
        plt.imshow(depth, cmap='Spectral_r')
        plt.axis('off')
        
        plt.subplot(1, 2, 2)
        plt.title("Outlier Removal (Red = Deleted)")
        plt.imshow(kill_map)
        plt.axis('off')
        
        debug_path = os.path.join(self.output_dir, "stage1_debug.jpg")
        plt.savefig(debug_path)
        plt.close()
        self.log(f"Saved debug view to {debug_path}")
        
        