from .baseline_projector import PipelineStage, CanonicalCamera
import numpy as np
import open3d as o3d
import cv2
import scipy.sparse as sp
from scipy.sparse.linalg import spsolve
import os
import matplotlib.pyplot as plt





class MaskedHealer(PipelineStage):
    """
    Stage 4: Metric-Aware Poisson Solver.
    CRITICAL FIX: Robust Slope & Divergence calculation to prevent Solver NaN.
    """
    def run(self, filled_depth_path, filled_normal_path, mask_path, lambda_fidelity=0.9):
        self.log(f"Running Metric Poisson Healing (Lambda={lambda_fidelity})...")
        
        # 1. Load Data
        D_init = np.load(filled_depth_path).astype(np.float64)
        N = np.load(filled_normal_path).astype(np.float64)
        mask_img = cv2.imread(mask_path, cv2.IMREAD_GRAYSCALE)
        mask = mask_img > 127
        
        num_vars = np.sum(mask)
        H, W = D_init.shape
        self.log(f"Solving for {num_vars} pixels...")

        # 2. Metric Scaling
        pixel_pitch = 1.1 / max(H, W)
        
        # 3. Calculate Slopes (Robustly)
        # We process the ENTIRE image to ensure gradients are valid at boundaries
        nx, ny, nz = N[..., 0], N[..., 1], N[..., 2]
        
        # A. Handle small Nz (Division by zero risk)
        # Force tiny Nz to be at least 0.01 (preserving sign)
        nz_sign = np.sign(nz)
        nz_sign[nz_sign == 0] = 1.0 
        nz_safe = np.where(np.abs(nz) < 0.01, 0.01 * nz_sign, nz)
        
        # B. Calculate Real Slopes
        Sx = -nx / nz_safe
        Sy = -ny / nz_safe
        
        # C. Sanitize Slopes (The NaN Killer)
        # Any nan/inf slopes (likely in background) become 0
        invalid_slopes = ~np.isfinite(Sx) | ~np.isfinite(Sy)
        Sx[invalid_slopes] = 0.0
        Sy[invalid_slopes] = 0.0
        
        # D. Metric Scaling
        Sx *= pixel_pitch
        Sy *= pixel_pitch
        
        # 4. Compute Divergence
        dSx = np.gradient(Sx, axis=1)
        dSy = np.gradient(Sy, axis=0)
        div_S = dSx + dSy
        
        # E. Sanitize Divergence (Double Check)
        div_S[~np.isfinite(div_S)] = 0.0
        
        # 5. Build Linear System
        id_map = -1 * np.ones((H, W), dtype=np.int32)
        id_map[mask] = np.arange(num_vars)
        
        rows, cols = np.where(mask)
        curr_ids = id_map[rows, cols]
        
        A_rows, A_cols, A_vals = [], [], []
        b_vec = np.zeros(num_vars, dtype=np.float64)
        
        # Fill b_vec
        b_vec += div_S[mask]
        b_vec += lambda_fidelity * D_init[mask]
        
        # SAFETY CHECK: Is b_vec valid?
        if not np.all(np.isfinite(b_vec)):
            n_nans = np.sum(~np.isfinite(b_vec))
            raise ValueError(f"Solver Crash imminent! b_vec contains {n_nans} NaNs/Infs.")
        
        # Diagonal Setup
        diag_vals = np.full(num_vars, 4.0 + lambda_fidelity, dtype=np.float64)
        
        # Neighbor Loop
        shifts = [(-1, 0), (1, 0), (0, -1), (0, 1)]
        for r_shift, c_shift in shifts:
            r_n = rows + r_shift
            c_n = cols + c_shift
            
            # Check bounds
            valid_coords = (r_n >= 0) & (r_n < H) & (c_n >= 0) & (c_n < W)
            valid_idx = np.where(valid_coords)[0]
            
            rn_v = r_n[valid_idx]
            cn_v = c_n[valid_idx]
            curr_node_ids = curr_ids[valid_idx]
            neigh_ids = id_map[rn_v, cn_v]
            
            # Case A: Variable Neighbor
            is_variable = neigh_ids != -1
            A_rows.append(curr_node_ids[is_variable])
            A_cols.append(neigh_ids[is_variable])
            A_vals.append(np.full(np.sum(is_variable), -1.0))
            
            # Case B: Boundary Neighbor (Fixed)
            is_boundary = ~is_variable
            
            # Get fixed depths from Stage 3 D_init
            fixed_depths = D_init[rn_v[is_boundary], cn_v[is_boundary]]
            
            # Safety Check on Boundary Values
            # If a boundary pixel is NaN (it shouldn't be, D_init is clean), treat as 0
            fixed_depths = np.nan_to_num(fixed_depths, nan=0.0)

            # Move to RHS (Equation: 4Z - Z_neigh = ... => 4Z = ... + Z_neigh)
            b_vec[curr_node_ids[is_boundary]] += fixed_depths

        # Add Diagonal
        A_rows.append(curr_ids)
        A_cols.append(curr_ids)
        A_vals.append(diag_vals)
        
        # 6. Solve
        self.log("Factorizing matrix...")
        A_mat = sp.csr_matrix((np.concatenate(A_vals), 
                              (np.concatenate(A_rows), np.concatenate(A_cols))), 
                              shape=(num_vars, num_vars))
        
        # Use spsolve (robust direct solver)
        Z_solved = spsolve(A_mat, b_vec)
        
        # 7. Reconstruct
        D_healed = D_init.copy()
        D_healed[mask] = Z_solved
        
        # Final NaN check
        if np.all(np.isnan(D_healed[mask])):
             self.log("CRITICAL ERROR: Solver returned all NaNs!")
        
        # 8. Save
        out_npy = os.path.join(self.output_dir, "stage4_healed_depth.npy")
        np.save(out_npy, D_healed.astype(np.float32))
        self.log(f"Saved Healed Depth: {out_npy}")
        
        self.save_final_cloud(D_healed, mask)
        self.save_healing_debug(D_init, D_healed, mask)
        
        return out_npy

    def save_final_cloud(self, depth, mask):
        points = self.cam.project_depth_to_points(depth.astype(np.float32), mask)
        pcd = o3d.geometry.PointCloud()
        pcd.points = o3d.utility.Vector3dVector(points)
        pcd.paint_uniform_color([0.5, 0.5, 0.5])
        pcd.estimate_normals()
        ply_path = os.path.join(self.output_dir, "stage4_final.ply")
        o3d.io.write_point_cloud(ply_path, pcd)
        self.log(f"Saved Final PLY: {ply_path}")

    def save_healing_debug(self, before, after, mask):
        delta = after - before
        v_max = np.nanpercentile(np.abs(delta[mask]), 98) + 1e-6
        
        plt.figure(figsize=(18, 6))
        plt.subplot(1, 3, 1); plt.title("Input"); plt.imshow(before, cmap='Spectral_r'); plt.axis('off')
        plt.subplot(1, 3, 2); plt.title("Healed"); plt.imshow(after, cmap='Spectral_r'); plt.axis('off')
        plt.subplot(1, 3, 3); plt.title(f"Delta +/- {v_max:.4f}"); plt.imshow(delta, cmap='bwr', vmin=-v_max, vmax=v_max); plt.axis('off')
        
        path = os.path.join(self.output_dir, "stage4_debug.jpg")
        plt.savefig(path)
        plt.close()