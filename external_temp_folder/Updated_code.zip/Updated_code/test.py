from stages.baseline_projector import BaselineProjector, CanonicalCamera
from stages.depth_sanitizer import DepthSanitizer, NormalSanitizer
from stages.data_infiller import DataInfiller
from stages.masked_healer import MaskedHealer
from visualizer.visualisePointClouds import MultiViewRenderer, CanonicalCamera_pointcloud


# --- EXECUTION ---
if __name__ == "__main__":
    # Config
    IN_DIR = "intermediate_input"
    OUT_DIR = "pipeline_results"
    
    rgb = f"{IN_DIR}/input_768_gray_bg.jpg"
    mask = f"{IN_DIR}/input_768_mask.png"
    depth_raw = f"{IN_DIR}/depth_npy/input_768_gray_bg_depth.npy"
    norm_raw = f"{IN_DIR}/normals_npy/input_768_gray_bg_normals.npy"
    
    
    viz_cam = CanonicalCamera_pointcloud()
    
    renderer = MultiViewRenderer(viz_cam)
    
    # Render Raw Depth Point Cloud (Before Any Processing)
    renderer.render_from_npy(depth_raw, rgb, "raw_depth_views")
    
    
    
    # 1. Baseline
    # 1. Define Camera
    my_cam = CanonicalCamera(resolution=768, bounds=0.55)    
    
    # 2. Initialize Stage with Camera
    stage1 = BaselineProjector(OUT_DIR, camera=my_cam)
    depth_clean = stage1.run(rgb, depth_raw, mask)
    
    # 3. Visualize Cleaned Depth Point Cloud
    renderer.render_from_npy(depth_clean, rgb, "cleaned_depth_views", mask_path=mask)
    
    
    
    stage1_5 = NormalSanitizer(OUT_DIR, camera=my_cam)
    norm_clean = stage1_5.run(norm_raw, mask)
    
    # 2. Sanitize
    # stage2 = DepthSanitizer(OUT_DIR, camera=my_cam)
    # clean_depth = stage2.run(depth_clean, norm_clean, mask)
    #Sanitize is destroying details 
    
    # 3. Infill
    stage3 = DataInfiller(OUT_DIR, camera=my_cam)
    filled_depth, filled_norm = stage3.run(depth_clean, norm_clean, mask)
    #Visualize Infilled Depth Point Cloud
    renderer.render_from_npy(filled_depth, rgb, "infilled_depth_views",mask_path=mask)
    
    # 4. Heal
    stage4 = MaskedHealer(OUT_DIR, camera=my_cam)
    stage4.run(filled_depth, filled_norm, mask)
    
    
    